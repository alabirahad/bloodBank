<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>

                    <th class="text-center vcenter">@lang('label.SL_NO')</th>
                    <th class="text-center vcenter">@lang('label.CRITERIA')</th>
                    <th class="text-center vcenter">@lang('label.WT')</th>

                </tr>
            </thead>

            <tbody>

                <?php
                $sl = 0;
                ?>
                <tr>
                    <td class="text-center vcenter">{!! ++$sl !!}</td>
                    <td class="text-left"> {!! $eventCriteriaArr[$sl] !!}</td>
                    <td class="text-center vcenter width-200">
                        {!! Form::text('written_ass_wt',!empty($criteriaWtArr['written_ass_wt']) ? $criteriaWtArr['written_ass_wt'] : null, ['id'=> 'writtenWtId', 'class' => 'form-control integer-decimal-only text-inherit text-right','autocomplete' => 'off']) !!}
                    </td>
                </tr>
                <tr>
                    <td class="text-center vcenter">{!! ++$sl !!}</td>
                    <td class="text-left"> {!! $eventCriteriaArr[$sl] !!}</td>
                    <td class="text-center vcenter width-200">
                        {!! Form::text('outdoor_event_wt',!empty($criteriaWtArr['outdoor_wt']) ? $criteriaWtArr['outdoor_wt'] : null, ['id'=> 'outdoorEventId', 'class' => 'form-control integer-decimal-only text-inherit text-right','autocomplete' => 'off']) !!}
                    </td>
                </tr>
                <tr>
                    <td class="text-center vcenter">{!! ++$sl !!}</td>
                    <td class="text-left"> {!! $eventCriteriaArr[$sl] !!}</td>
                    <td class="text-center vcenter width-200">
                        {!! Form::text('obsn_wt',!empty($criteriaWtArr['obsn_wt']) ? $criteriaWtArr['obsn_wt'] : null, ['id'=> 'obsnId', 'class' => 'form-control integer-decimal-only text-inherit text-right','autocomplete' => 'off']) !!}
                    </td>
                </tr>
                <tr>
                    <td class="text-center vcenter">{!! ++$sl !!}</td>
                    <td class="text-left"> {!! $eventCriteriaArr[$sl] !!}</td>
                    <td class="text-center vcenter width-200">
                        {!! Form::text('misc_wt',!empty($criteriaWtArr['misc_wt']) ? $criteriaWtArr['misc_wt'] : null, ['id'=> 'miscId', 'class' => 'form-control integer-decimal-only text-inherit text-right','autocomplete' => 'off']) !!}
                    </td>
                </tr>
                <tr>
                    <td class=" text-right bold" colspan="2"> @lang('label.TOTAL') </td>
                    <td class="text-right width-200">
                        <span class="total-wt bold">{!! !empty($criteriaWtArr['total_wt']) ? $criteriaWtArr['total_wt'] : '' !!}</span>
                        {!! Form::hidden('total',null,['class' => 'total-wt']) !!}
                    </td>
                </tr>
            </tbody>
        </table>

        <div class="form-actions">
            <div class="row">
                <div class="col-md-offset-5 col-md-5">
                    <button class="btn btn-circle green button-submit" type="button" id="buttonSubmit" >
                        <i class="fa fa-check"></i> @lang('label.SUBMIT')
                    </button>
                    <a href="{{ URL::to('criteriaWiseWt') }}" class="btn btn-circle btn-outline grey-salsa">@lang('label.CANCEL')</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $(document).on('keyup', '#writtenWtId', function () {
            var writtenAss = $(this).val();
            var totalSum = $('.total-wt').text();
            if (isNaN(writtenAss)) {
                $("#writtenWtId").val('');
                $("#writtenWtId").focus();
                return false;
            }
            total();
        });
        $(document).on('keyup', '#outdoorEventId', function () {
            var outDoorEvent = $(this).val();
            if (isNaN(outDoorEvent)) {
                $("#outdoorEventId").val('');
                $("#outdoorEventId").focus();
                return false;
            }
            total();
        });
        $(document).on('keyup', '#obsnId', function () {
            var obsn = $(this).val();
            if (isNaN(obsn)) {
                $("#obsnId").val('');
                $("#obsnId").focus();
                return false;
            }
            total();
        });
        $(document).on('keyup', '#miscId', function () {
            var misc = $(this).val();
            if (isNaN(misc)) {
                $("#miscId").val('');
                $("#miscId").focus();
                return false;
            }
            total();
        });

        function total() {
            var writtenAss = $('#writtenWtId').val();
            var outDoorEvent = $('#outdoorEventId').val();
            var obsnWt = $('#obsnId').val();
            var miscWt = $('#miscId').val();
            //var total = 0;
            var total = parseFloat(Number(writtenAss) + Number(outDoorEvent) + Number(obsnWt) + Number(miscWt)).toFixed(2);
            $(".total-wt").text(total);
            $(".total-wt").val(total);
        }
    });
</script>


